#include "global.h"

#include <stdio.h>
#include <string.h>

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "app.h"
#include "sys.h"

// defines
// ...


// declarations and definations

volatile struct App app;


// functions

void app_init (void)
{
  memset((void *)&app, 0, sizeof(app));
  ADMUX = (1<<REFS1) | (1<<REFS0) | (1<<ADLAR) | 0x08; //0x08.... Tempsensor
  ADCSRA = (1<<ADEN) | 7; // durch 128 -> das ergibt eine frequenz von 125kHz (eine ADC Umwandlung benötigt 128µs)
  app.modbus.frameIndex = -1;
}


//--------------------------------------------------------

void app_main (void)
{
  printf("ADCH= %u  \r", app.adch);
  _delay_ms(200);
}

//--------------------------------------------------------

void app_task_1ms (void) 
{
  app_handleUartByte();
}
void app_task_2ms (void) {}
void app_task_4ms (void) {}
void app_task_8ms (void) {}
void app_task_16ms (void) {
  app.adch=ADCH;
  ADCSRA |= (1<< ADSC); //Starte ADC
  
}
void app_task_32ms (void) {}
void app_task_64ms (void) {}
void app_task_128ms (void) {}
void app_parseModbusFrame(){
  app.modbusForPrint = app.modbus;
  sys_setEvent(APP_EVENT_MODBUS);
}
void app_handleUartByte (char c)
{
  struct Modbus *p = &app.modbus;
  
  if (p ->frameIndex <0){
    if(c==':'){
      p->frameIndex =0;
      p->frameError =0;
    } else {
      if(p -> invalidByteCount < 0xffff){
        p->invalidByteCount++;
      }
    }
    
  } else {
    if(c==':'){
      p->frameIndex=0;
      p->frameError = 0; 
      if(p->errorcounter < 0xffff)
        p->errorcounter++;
      
    } else {
    
    //in buffer speichern
    if (p->frameIndex < sizeof p->frame)
    p->frame [p->frameIndex++] = c;
    
    else {
      p-> frameError = 1;
    }
    if(c== '\n')
      app_parseModbusFrame();
      p->frameIndex = -1;
      p->frameError = 0; 
    }
  }
}